// Implementación de referencia: validación del PIN exclusivamente en el servidor.
// No publicar sin integrar sesiones verificadas, autorización por rol y protección de operaciones.
import { createClient } from 'npm:@supabase/supabase-js@2';
Deno.serve(async (req) => {
  if (req.method !== 'POST') return new Response('Método no permitido', { status: 405 });
  // Seguridad: solo admite el origen configurado, sin comodines.
  const origin = req.headers.get('origin') || '';
  const allowed = Deno.env.get('APP_ORIGIN');
  if (!allowed || origin !== allowed) return new Response('Origen no autorizado', { status: 403 });
  const json = (data: unknown, status = 200) => new Response(JSON.stringify(data), {
    status, headers: { 'content-type': 'application/json', 'access-control-allow-origin': allowed, 'vary': 'Origin' }
  });
  let input: { usuario?: string; pin?: string };
  try { input = await req.json(); } catch { return json({ error: 'Solicitud inválida' }, 400); }
  const usuario = String(input.usuario || '').trim().toLowerCase();
  const pin = String(input.pin || '');
  if (!/^[\p{L}\p{N}_.-]{2,60}$/u.test(usuario) || !/^\d{4}$/.test(pin)) return json({ error: 'Credenciales inválidas' }, 401);
  const url = Deno.env.get('SUPABASE_URL');
  const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  if (!url || !serviceKey) return json({ error: 'Configuración incompleta' }, 503);
  const admin = createClient(url, serviceKey, { auth: { persistSession: false } });
  // Bloqueo persistente por usuario: las peticiones concurrentes y los ataques distribuidos
  // requieren además un limitador por IP en el perímetro.
  const { data, error } = await admin.rpc('tc_verificar_pin', { p_usuario: usuario, p_pin: pin });
  if (error) return json({ error: 'Servicio temporalmente no disponible' }, 503);
  if (!data?.ok) return json({ error: 'Credenciales inválidas o temporalmente bloqueadas' }, 401);
  // NO se entrega una sesión hasta implementar token firmado, expiración y autorización.
  return json({ error: 'Verificación preparada; emisión de sesión pendiente' }, 503);
});
