-- TIME CONTROL: Preparación no destructiva para autenticación con PIN.
-- NO EJECUTAR en producción hasta migrar el frontend y la administración de usuarios.
-- Este archivo NO habilita permisos públicos UPDATE/DELETE.
CREATE EXTENSION IF NOT EXISTS pgcrypto;
ALTER TABLE public.usuarios ADD COLUMN IF NOT EXISTS pin_hash text;
ALTER TABLE public.usuarios ADD COLUMN IF NOT EXISTS pin_fallos integer NOT NULL DEFAULT 0;
ALTER TABLE public.usuarios ADD COLUMN IF NOT EXISTS pin_bloqueado_hasta timestamptz;
-- Migración inicial: cada PIN actual se convierte a hash en el servidor.
-- Revisar y rotar PINs por defecto ANTES de desplegar; los PINs de 4 dígitos requieren límites estrictos.
UPDATE public.usuarios SET pin_hash = crypt(pin, gen_salt('bf', 12)) WHERE pin_hash IS NULL AND pin IS NOT NULL;
-- La columna pin original se debe retirar únicamente después de adaptar y probar todo el frontend.
-- NO habilitar RLS de usuarios sin las políticas y autenticación completas.
